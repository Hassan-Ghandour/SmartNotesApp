using Microsoft.AspNetCore.Mvc;
using Backend.Models;

namespace Backend.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private static List<User> users = new();
    private static int nextId = 1;

    [HttpPost("register")]
    public IActionResult Register(User newUser)
    {
        if (users.Any(u => u.Username == newUser.Username))
            return Conflict("Nom d'utilisateur déjà pris");

        newUser.Id = nextId++;
        users.Add(newUser);
        return Ok(new { message = "Inscription réussie" });
    }

    [HttpPost("login")]
    public IActionResult Login(User credentials)
    {
        var user = users.FirstOrDefault(u => u.Username == credentials.Username && u.Password == credentials.Password);
        if (user == null)
            return Unauthorized("Nom d'utilisateur ou mot de passe invalide");

        return Ok(new { username = user.Username });
    }
}
