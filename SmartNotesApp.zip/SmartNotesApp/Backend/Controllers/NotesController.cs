using Microsoft.AspNetCore.Mvc;
using Backend.Models;

namespace Backend.Controllers;

[ApiController]
[Route("[controller]")]
public class NotesController : ControllerBase
{
    private static List<Note> notes = new();

    [HttpGet]
    public ActionResult<List<Note>> Get()
    {
        return notes
            .OrderByDescending(n => n.Date) 
            .ToList();
    }

    [HttpGet("{id}")]
    
    public ActionResult<Note> Get(int id)
    {
        var note = notes.FirstOrDefault(n => n.Id == id);
        if (note == null) return NotFound();
        return note;
    }

    [HttpPost]
    public ActionResult<Note> Post(Note note)
    {
        note.Id = notes.Count > 0 ? notes.Max(n => n.Id) + 1 : 1;
        notes.Add(note);
        return CreatedAtAction(nameof(Get), new { id = note.Id }, note);
    }

    [HttpPut("{id}")]
    public IActionResult Put(int id, Note updatedNote)
    {
        var note = notes.FirstOrDefault(n => n.Id == id);
        if (note == null) return NotFound();
        note.Titre = updatedNote.Titre;
        note.Contenu = updatedNote.Contenu;
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var note = notes.FirstOrDefault(n => n.Id == id);
        if (note == null) return NotFound();
        notes.Remove(note);
        return NoContent();
    }
    
}