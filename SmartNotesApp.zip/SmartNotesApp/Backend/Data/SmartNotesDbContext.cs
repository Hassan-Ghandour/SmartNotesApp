using Microsoft.EntityFrameworkCore;
using Backend.Models;

namespace Backend.Data
{
    public class SmartNotesDbContext : DbContext
    {
        public SmartNotesDbContext(DbContextOptions<SmartNotesDbContext> options) : base(options) { }

        public DbSet<Note> Notes { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
