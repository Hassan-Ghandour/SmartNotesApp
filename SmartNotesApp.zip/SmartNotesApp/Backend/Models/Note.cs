namespace Backend.Models;

public class Note
{
    public int Id { get; set; }
    public string Titre { get; set; } = "";
    public string Contenu { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Now;

    public int UserId { get; set; }
    public User? User { get; set; }
}

