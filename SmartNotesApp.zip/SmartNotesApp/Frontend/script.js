const api = "http://localhost:5164/notes"; 
let editingId = null;

document.getElementById("noteForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("title").value;
  const content = document.getElementById("content").value;

  if (editingId) {
    await fetch(`${api}/${editingId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titre: title, contenu: content }),
    });
    editingId = null;
    document.querySelector("button[type=submit]").innerText = "Ajouter";
  } else {
    await fetch(api, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titre: title, contenu: content }),
    });
  }

  document.getElementById("title").value = "";
  document.getElementById("content").value = "";
  loadNotes();
});

document.getElementById("searchInput").addEventListener("input", function () {
  const searchTerm = this.value.toLowerCase();
  const notes = document.querySelectorAll("#notesList li");

  notes.forEach(note => {
    const title = note.querySelector("strong").textContent.toLowerCase();
    const content = note.querySelector("p")?.textContent?.toLowerCase() || "";

    if (title.includes(searchTerm) || content.includes(searchTerm)) {
      note.style.display = "flex";
    } else {
      note.style.display = "none";
    }
  });
});

async function loadNotes() {
  const res = await fetch(api);
  const notes = await res.json();
  const list = document.getElementById("notesList");
  list.innerHTML = "";

  notes.forEach(note => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="note-content">
        <div>
          <strong>${note.titre}</strong><br>
          ${note.contenu}<br>
          <small style="color: gray;">${new Date(note.date).toLocaleString()}</small>
        </div>
        <div class="note-actions">
          <button onclick="editNote(${note.id})" title="Modifier">
            <img src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png" style="filter: brightness(0) invert(1);" width="20"/>
          </button>
          <button onclick="deleteNote(${note.id})" title="Supprimer">
            <img src="https://cdn-icons-png.flaticon.com/512/1214/1214428.png" style="filter: brightness(0) invert(1);" width="20"/>
          </button>
        </div>
      </div>
    `;
    list.appendChild(li);
  });
}

async function deleteNote(id) {
  await fetch(`${api}/${id}`, { method: "DELETE" });
  loadNotes();
}

async function editNote(id) {
  const res = await fetch(`${api}/${id}`);
  const note = await res.json();
  document.getElementById("title").value = note.titre;
  document.getElementById("content").value = note.contenu;
  editingId = id;
  document.querySelector("button[type=submit]").innerText = "Mettre à jour";
}


loadNotes();
